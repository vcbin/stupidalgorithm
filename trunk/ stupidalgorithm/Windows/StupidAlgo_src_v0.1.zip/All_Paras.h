#ifndef JERRYLIU_ALL_ALGO_CONF
#define JERRYLIU_ALL_ALGO_CONF

#include "PSO_Paras.h"
#include "DE_Paras.h"
#include "EP_Paras.h"
#include "GA_Paras.h"

#endif