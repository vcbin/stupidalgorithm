#ifndef STUPIDALGO_ALL_ALGO_CONF
#define STUPIDALGO_ALL_ALGO_CONF

#include "pso_para.h"
#include "de_para.h"
#include "ep_para.h"
#include "ga_para.h"

#endif